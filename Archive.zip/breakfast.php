<?php include("head_nav.html"); ?>
            
             <div class="box main">
            <h2>Strawberry and Banana Smoothie</h2>
        
   <p>Rating: <span class="sub_heading">&#9733;&#9733;&#9733;&#9733;</span></p>
                 
                 <p> My favourite dish for breakfast is a strawberry and banana smoothie. </p>
                 
                 <p>
                 This is a pretty straightforward and simple dish to make but also tastes so good. To make this dish it just requires a handful of strawberries, bananas, ice and some milk. Then you just throw that all in a smoothie maker or blender and it’s ready to drink!
                 </p>
                 <p>  
                 What i love about this dish is that it requires no culinary skills and can be made in just minutes. Which is perfect for me as I have little cooking abilities and also no time in the mornings when I have to rush to school.
                 </p>
                 <p>
                 Smoothies are the best go-to option in the mornings because of how fast and easy it is to prepare and also how good it tastes.
                 </p>

                 
            </div>   <!-- / main -->
            
             <div class="box side">
                 
                <div class="center_image">
          
     <img class="img-circle" src="Images/breakfast.jpg" alt="" />
                    
    </div>
                      
            <p><i>The best way to fully wake yourself up and prepare to face the day, head-on, is by starting your mornings with a smoothie. </i></p>

            </div>   <!-- / side -->
            
<?php include("footer.html"); ?>