<?php include("head_nav.html"); ?>

      <div class="box main">
 <iframe class="contact" src="https://docs.google.com/forms/d/e/1FAIpQLSeYPW2zovfVZ72VLkEEoklwP09b40rNTdJ4p2jP_kXq85ItVw/viewform?embedded=true" height="530"></iframe>

 </div>   <!-- / main --> 
      
  <div class="box side">
      
      <div class="center_image">
          
     <img class="img-circle" src="Images/contact.jpg" alt="" />
    </div>
      
       <h3>About Me:</h3> 
           
      <p><i>My name is Naumi Teinabo and I am 15 years old. I currently attend Mahurangi College.</i></p>
      
      <p><i>I have created a contact form so anyone viewing this website can ask me questions or give feedback!</i></p>
      </div>   <!-- / side bar --> 
      
<?php include("footer.html"); ?>