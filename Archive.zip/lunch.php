<?php include("head_nav.html"); ?>
            
             <div class="box main">
            <h2>Sushi</h2>
                 
                 
        <p>Rating: <span class="sub_heading">&#9733;&#9733;&#9733;&#9733;&#9733;</span></p>
                 
                 <p>
                     For lunch my all time favourite dish would definitely have to be sushi, preferably chicken and avocado sushi! 
                 </p>
                 <p>
                     Sushi is a Japanese dish and is made up of sushi, nori (seaweed), vegetables and seafood/meat. Sushi does require a bit of culinary skills but is fairly easy to make. 
                 </p>
                 <p>
                     The reason I love this dish is because of how good it tastes and how simple it is. I love how sushi can have a large variety of ingredients in it instead of just the same specific ingredients. You can have chicken or seafood in it, avocado or carrots and it will still taste good no matter what! Sushi is also fairly healthy and is quite filling. Sushi is the perfect dish for any day and provides you with a healthy meal.
                 </p>
                 
                 
            </div>   <!-- / main -->
            
             <div class="box side">
                    <div class="center_image">
          
      <img class="img-circle" src="Images/lunch.jpg" alt="" /> 
                        
    </div>
               
            <p><i>Having sushi is perfect during a day out or during your school lunch break.</i></p>
                 
            </div>   <!-- / side -->
            
<?php include("footer.html"); ?>