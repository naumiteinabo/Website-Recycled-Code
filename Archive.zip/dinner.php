<?php include("head_nav.html"); ?>
            
             <div class="box main">
            <h2>Homemade Vegetarian Pizza</h2>
                 
         <p>Rating: <span class="sub_heading">&#9733;&#9733;&#9733;&#9733;&#9733;</span></p> 

                 
    <p>
    For dinner my favourite dish would hands-down have to be vegetarian pizza, sometimes I order it from pizza stores or just make it myself. I definitely prefer homemade pizza as I find it a lot more healthier! 
    </p>
    <p>
        This dish is quite self explanatory, it is just vegetables such as tomatoes, spinach and mushrooms with mozzarella cheese sprinkled over a dough base with a tomato sauce spread. This is personally my favourite toppings to have on my pizza as they taste so good together and is super juicy. 
     </p>
     <p>
This is my favourite dish for dinner as it’s always so much fun making the pizza and is super delicious. I love how making pizza requires little effort and is a fun activity for my family and I. Growing up, pizza has always been my favourite dish as well as my siblings and it’s always been a great way for us to bond. 
                 </p>
                         
     </div>   <!-- / main -->
            
             <div class="box side">
                 
                   <div class="center_image">
          
     <img class="img-circle" src="Images/dinner.jpg" alt="" />
    </div>
               
        <p><i>With pizza you can choose whatever flavours and toppings you want! The possibilities are endless. It is perfect for all ages and is a fun activity to do.</i></p>
            </div>   <!-- / side -->
            
<?php include("footer.html"); ?>